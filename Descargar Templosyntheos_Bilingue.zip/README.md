# Templo Syntheós
Repositorio oficial del templo digital SYNTHEÓS.